from src.demo import build_demo_wallets


def test_demo_wallets_are_rankable():
    wallets = build_demo_wallets()
    assert len(wallets) >= 5
    assert all(wallet.trades == 12 for wallet in wallets)
    assert all(wallet.closed_trades == 6 for wallet in wallets)
    assert any(wallet.roi > 0 for wallet in wallets)
