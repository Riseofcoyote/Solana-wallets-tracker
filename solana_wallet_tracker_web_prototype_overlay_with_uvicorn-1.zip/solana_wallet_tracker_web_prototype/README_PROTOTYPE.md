# Solana Wallet Tracker — working web prototype overlay

This overlay turns the Python wallet scanner into a local web prototype.

## What works now

- Demo scan with no API keys.
- CSV upload/filter mode.
- API scan mode using your existing `.env` keys.
- Ranked wallet table in the browser.
- CSV exports:
  - `output/top_wallets.csv`
  - `output/top_5_research_candidates.csv`
- Best-effort realized PnL estimation from recent SOL/token swap flows.
- No wallet private keys, no signing, no custody, no live trading.

## Install

From the repo root:

```bash
git checkout add-web-interface
# or: git checkout prototype-realized-pnl-scanner

# copy this overlay into the repo root, then:
python -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt

# requirements.txt includes uvicorn[standard], which runs the FastAPI web UI.
cp .env.example .env
```

## Run the web UI

```bash
uvicorn src.web:app --reload
```

Open the local URL shown by Uvicorn, usually:

```text
http://127.0.0.1:8000
```

## Run the CLI demo

```bash
python -m src.main
```

## API scan setup

Edit `.env`:

```env
DEMO_MODE=false
HELIUS_API_KEY=your_helius_api_key
BIRDEYE_API_KEY=your_birdeye_api_key
SEED_WALLETS=wallet1,wallet2,wallet3
```

Then choose **API scan** in the web UI.

## CSV mode

Upload a CSV with these columns:

```text
wallet,win_rate,roi,avg_buy_size_sol,trades,last_trade_at
```

`avg_buy_size` is also accepted and normalized to `avg_buy_size_sol`.

## Prototype limitations

This is a research prototype. The realized PnL scanner estimates PnL using recent transaction payloads and average-cost positions. Exact wallet PnL needs deeper history, fees, token decimals validation, wrapped SOL route handling, and aggregator edge-case support.
