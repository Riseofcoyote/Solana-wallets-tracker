"""Solana wallet tracker prototype."""
