from __future__ import annotations

import contextlib
import io
import os
import shutil
from pathlib import Path
from typing import Iterator

import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .demo import run_demo
from .main import analyze_existing_csv, run_api_scan


ROOT_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT_DIR / "output"
UPLOAD_DIR = ROOT_DIR / "uploads"
DEFAULT_OUTPUT_FILE = OUTPUT_DIR / "top_wallets.csv"
TOP_FIVE_FILE = OUTPUT_DIR / "top_5_research_candidates.csv"

load_dotenv(ROOT_DIR / ".env")

app = FastAPI(title="Solana Wallet Tracker Prototype")
app.mount("/static", StaticFiles(directory=Path(__file__).resolve().parent / "static"), name="static")
templates = Jinja2Templates(directory=Path(__file__).resolve().parent / "templates")


@app.get("/")
def index(request: Request):
    context = _base_context(request)
    context.update(_read_output_context())
    return templates.TemplateResponse("index.html", context)


@app.post("/scan")
async def scan(
    request: Request,
    mode: str = Form("demo"),
    lookback_hours: int = Form(48),
    min_win_rate: float = Form(0.50),
    min_trades: int = Form(10),
    min_avg_buy_sol: float = Form(0.5),
    top_wallets: int = Form(100),
    max_wallets_to_score: int = Form(200),
    seed_wallets: str = Form(""),
    discovery_token_mints: str = Form("So11111111111111111111111111111111111111112"),
    dexscreener_discovery: str | None = Form(None),
    csv_file: UploadFile | None = File(None),
):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

    env_updates = {
        "OUTPUT_FILE": str(DEFAULT_OUTPUT_FILE),
        "LOOKBACK_HOURS": str(lookback_hours),
        "MIN_WIN_RATE": str(min_win_rate),
        "MIN_TRADES": str(min_trades),
        "MIN_AVG_BUY_SOL": str(min_avg_buy_sol),
        "TOP_WALLETS": str(top_wallets),
        "MAX_WALLETS_TO_SCORE": str(max_wallets_to_score),
        "SEED_WALLETS": seed_wallets.strip(),
        "DISCOVERY_TOKEN_MINTS": discovery_token_mints.strip(),
        "DEXSCREENER_DISCOVERY": "true" if dexscreener_discovery else "false",
    }

    log_buffer = io.StringIO()
    status = "Scan complete."

    try:
        with _patched_environ(env_updates), contextlib.redirect_stdout(log_buffer):
            if mode == "demo":
                full_output, top_output = run_demo(str(DEFAULT_OUTPUT_FILE))
                status = f"Demo scan complete. Saved {full_output} and {top_output}."
            elif mode == "csv":
                uploaded_path = await _save_upload(csv_file)
                full_output, top_output = analyze_existing_csv(str(uploaded_path), str(DEFAULT_OUTPUT_FILE))
                status = f"CSV analysis complete. Saved {full_output} and {top_output}."
            elif mode == "api":
                full_output, top_output, wallet_count = run_api_scan(str(DEFAULT_OUTPUT_FILE))
                status = f"API scan complete. Saved {wallet_count} ranked wallet(s) to {full_output}."
            else:
                raise ValueError(f"Unknown scan mode: {mode}")
    except Exception as exc:
        status = f"Error: {exc}"

    context = _base_context(request)
    context.update(_read_output_context())
    context.update({"status": status, "logs": log_buffer.getvalue(), "last_mode": mode})
    return templates.TemplateResponse("index.html", context)


@app.get("/download/full")
def download_full():
    if not DEFAULT_OUTPUT_FILE.exists():
        return RedirectResponse("/")
    return FileResponse(DEFAULT_OUTPUT_FILE, media_type="text/csv", filename="top_wallets.csv")


@app.get("/download/top5")
def download_top5():
    if not TOP_FIVE_FILE.exists():
        return RedirectResponse("/")
    return FileResponse(TOP_FIVE_FILE, media_type="text/csv", filename="top_5_research_candidates.csv")


def _base_context(request: Request) -> dict:
    return {
        "request": request,
        "status": "",
        "logs": "",
        "last_mode": "demo",
        "defaults": {
            "lookback_hours": int(os.getenv("LOOKBACK_HOURS", "48")),
            "min_win_rate": float(os.getenv("MIN_WIN_RATE", "0.50")),
            "min_trades": int(os.getenv("MIN_TRADES", "10")),
            "min_avg_buy_sol": float(os.getenv("MIN_AVG_BUY_SOL", "0.5")),
            "top_wallets": int(os.getenv("TOP_WALLETS", "100")),
            "max_wallets_to_score": int(os.getenv("MAX_WALLETS_TO_SCORE", "200")),
            "seed_wallets": os.getenv("SEED_WALLETS", ""),
            "discovery_token_mints": os.getenv(
                "DISCOVERY_TOKEN_MINTS", "So11111111111111111111111111111111111111112"
            ),
            "dexscreener_discovery": os.getenv("DEXSCREENER_DISCOVERY", "false").lower()
            in {"1", "true", "yes", "y", "on"},
        },
    }


def _read_output_context() -> dict:
    rows: list[dict] = []
    columns: list[str] = []
    has_output = DEFAULT_OUTPUT_FILE.exists()

    if has_output:
        try:
            df = pd.read_csv(DEFAULT_OUTPUT_FILE)
            columns = list(df.columns)
            rows = df.head(100).fillna("").to_dict(orient="records")
        except Exception as exc:
            rows = [{"error": f"Could not read output CSV: {exc}"}]
            columns = ["error"]

    return {
        "rows": rows,
        "columns": columns,
        "has_output": has_output,
        "has_top5": TOP_FIVE_FILE.exists(),
        "output_file": str(DEFAULT_OUTPUT_FILE),
    }


async def _save_upload(csv_file: UploadFile | None) -> Path:
    if csv_file is None or not csv_file.filename:
        raise ValueError("CSV mode requires a CSV upload.")

    safe_name = Path(csv_file.filename).name
    if not safe_name.lower().endswith(".csv"):
        raise ValueError("Uploaded file must be a .csv file.")

    destination = UPLOAD_DIR / safe_name
    with destination.open("wb") as buffer:
        shutil.copyfileobj(csv_file.file, buffer)

    return destination


@contextlib.contextmanager
def _patched_environ(values: dict[str, str]) -> Iterator[None]:
    original = {key: os.environ.get(key) for key in values}

    try:
        for key, value in values.items():
            os.environ[key] = value
        yield
    finally:
        for key, value in original.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
