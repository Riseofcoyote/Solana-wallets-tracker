from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import requests


DEFAULT_SOLSCAN_ACCOUNT_TRANSFER_URL = "https://pro-api.solscan.io/v2.0/account/transfer"


@dataclass
class SolscanActivitySummary:
    wallet: str
    active_in_lookback: bool
    last_transfer_at: str = ""
    transfer_count: int = 0


class SolscanClient:
    """Small optional Solscan enrichment client.

    The prototype treats Solscan as verification only. API failures should not
    block the main scanner unless you choose to enforce that behavior later.
    """

    def __init__(
        self,
        api_key: str,
        account_transfer_url: str = DEFAULT_SOLSCAN_ACCOUNT_TRANSFER_URL,
        auth_header: str = "token",
    ) -> None:
        self.api_key = api_key
        self.account_transfer_url = account_transfer_url
        self.auth_header = auth_header or "token"
        self.session = requests.Session()
        self.session.headers.update({self.auth_header: self.api_key, "Accept": "application/json"})

    def summarize_wallet_activity(self, wallet: str, lookback_hours: int) -> SolscanActivitySummary:
        response = self.session.get(
            self.account_transfer_url,
            params={"address": wallet, "page": 1, "page_size": 20, "sort_by": "block_time", "sort_order": "desc"},
            timeout=30,
        )
        response.raise_for_status()

        payload = response.json()
        items = _extract_items(payload)
        cutoff = datetime.now(timezone.utc).timestamp() - (lookback_hours * 3600)

        last_transfer_at = ""
        active = False
        for item in items:
            timestamp = _extract_timestamp(item)
            if timestamp <= 0:
                continue
            if not last_transfer_at:
                last_transfer_at = datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()
            if timestamp >= cutoff:
                active = True

        return SolscanActivitySummary(
            wallet=wallet,
            active_in_lookback=active,
            last_transfer_at=last_transfer_at,
            transfer_count=len(items),
        )


def _extract_items(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        return []

    for key in ("data", "items", "result"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            for nested_key in ("items", "data", "result"):
                nested = value.get(nested_key)
                if isinstance(nested, list):
                    return [item for item in nested if isinstance(item, dict)]

    return []


def _extract_timestamp(item: dict[str, Any]) -> float:
    for key in ("block_time", "blockTime", "timestamp", "time"):
        value = item.get(key)
        if value is None:
            continue
        try:
            return float(value)
        except (TypeError, ValueError):
            continue
    return 0.0
